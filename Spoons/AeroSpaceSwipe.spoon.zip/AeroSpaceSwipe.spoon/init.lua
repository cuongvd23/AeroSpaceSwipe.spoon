local ControllerModule = {}
local releaseConfirmationDelay = 0.05

function ControllerModule.newRecognizer(options)
	options = options or {}
	local recognizer = {}
	function recognizer:reset()
		self.origins, self.latched, self.releasePending = nil, false, false
	end

	function recognizer:confirmRelease()
		if not self.releasePending then
			return false
		end
		self:reset()
		return true
	end

	function recognizer:expire()
		-- Keep the fired latch until fingers lift.
		self.origins = nil
	end

	function recognizer:update(touches)
		if not touches then
			return nil, false
		end
		local active, cancelled = {}, false
		for _, touch in ipairs(touches) do
			if touch.type == "indirect" and touch.identity and touch.normalizedPosition then
				if touch.touching then
					active[#active + 1] = touch
				elseif touch.phase == "cancelled" then
					cancelled = true
				end
			end
		end
		if #active == 0 then
			-- Empty frames can occur between movements from the same fingers.
			self.releasePending = true
			return nil, false
		end
		self.releasePending = false
		if cancelled then
			self.origins, self.latched = nil, true
			return nil, true
		end
		-- Only a full release rearms recognition, even if touch IDs or phases change.
		if self.latched then
			return nil, false
		end
		if #active ~= 4 then
			self.origins = nil
			return nil, false
		end
		local sameContacts = self.origins ~= nil
		for _, touch in ipairs(active) do
			sameContacts = sameContacts and self.origins[touch.identity] ~= nil and touch.phase ~= "began"
		end
		if not sameContacts then
			self.origins = {}
			for _, touch in ipairs(active) do
				self.origins[touch.identity] = { x = touch.normalizedPosition.x, y = touch.normalizedPosition.y }
			end
			return nil, false
		end
		local dx, dy, left, right = 0, 0, true, true
		local minimumFingerTravel = options.fingerThreshold or 0.002
		for _, touch in ipairs(active) do
			local origin = self.origins[touch.identity]
			local x = touch.normalizedPosition.x - origin.x
			dx, dy = dx + x, dy + touch.normalizedPosition.y - origin.y
			left, right = left and x <= -minimumFingerTravel, right and x >= minimumFingerTravel
		end
		dx, dy = dx / 4, dy / 4
		if
			math.abs(dx) >= (options.threshold or 0.01)
			and math.abs(dx) >= math.abs(dy) * (options.horizontalRatio or 1.5)
			and (left or right)
		then
			self.latched = true
			return left and "left" or "right", false
		end
		return nil, false
	end

	recognizer:reset()
	return recognizer
end

local function displayPattern(name)
	return "^"
		.. name:gsub(".", function(char)
			return ("\\^$.*+?()[]{}|"):find(char, 1, true) and "\\" .. char or char
		end)
		.. "$"
end

local function quoteArgument(value)
	return '"' .. value:gsub("\\", "\\\\"):gsub('"', '\\"') .. '"'
end

local Controller = {}
Controller.__index = Controller

local function oneShot(timers, delay, callback)
	local timer
	timer = timers.new(delay, function()
		timer:stop()
		callback()
	end)
	return {
		start = function()
			timer:setNextTrigger(delay)
		end,
		stop = function()
			timer:stop()
		end,
	}
end

-- Accessibility window lists omit native menus and some status-item popovers.
-- Consult the Window Server before automatic focus can dismiss those surfaces.
local function pointerFocusBlocked(runtime)
	local focused = runtime.window.focusedWindow()
	if focused and not focused:isStandard() then
		return true -- Dialogs and sheets retain focus until explicitly dismissed.
	end
	local point = runtime.mouse.absolutePosition()
	local windows = runtime.window.list(true)
	if not windows then
		return true
	end
	for _, window in ipairs(windows) do
		local frame, layer = window.kCGWindowBounds, window.kCGWindowLayer or 0
		if window.kCGWindowIsOnscreen ~= false and (window.kCGWindowAlpha or 1) > 0 and frame then
			if frame.Width > 0 and frame.Height > 0 then
				-- kCGPopUpMenuWindowLevel: pause even between a menu and its submenu.
				if layer == 101 then
					return true
				end
				if
					layer > 0
					and point.x >= frame.X
					and point.x < frame.X + frame.Width
					and point.y >= frame.Y
					and point.y < frame.Y + frame.Height
				then
					return true
				end
			end
		end
	end
	return false
end

-- Construct without starting so the controller owns the entire listener lifecycle.
function ControllerModule.newHoverFocus(options, runtime, isBlocked, onError)
	local generation, task, active, pending = 0, nil, false, false
	local cancel, timeout
	local function blocked()
		return not active or isBlocked() or next(runtime.eventtap.checkMouseButtons()) ~= nil
	end
	local timer = oneShot(runtime.timer, 0.1, function()
		pending = false
		if blocked() or pointerFocusBlocked(runtime) then
			return
		end
		local focused = runtime.window.focusedWindow()
		local screen = runtime.mouse.getCurrentScreen()
		local focusedScreen = focused and focused:screen()
		if not focusedScreen or not screen or focusedScreen:id() ~= screen:id() then
			return -- Monitor crossings belong to focusFollowsMouse.
		end
		local requestGeneration, focusedID = generation, focused:id()
		task = runtime.task.new(options.aerospacePath, function(code, output, stderr)
			if requestGeneration ~= generation then
				return
			end
			task = nil
			timeout:stop()
			if code ~= 0 then
				onError("Hover query failed (" .. tostring(code) .. "): " .. (stderr or ""))
				return
			end
			local current = runtime.window.focusedWindow()
			local point = runtime.mouse.absolutePosition()
			local pointerScreen = runtime.mouse.getCurrentScreen()
			if
				blocked()
				or pointerFocusBlocked(runtime)
				or not current
				or current:id() ~= focusedID
				or not pointerScreen
				or pointerScreen:id() ~= screen:id()
			then
				return
			end
			local allowed = {}
			for id, layout in output:gmatch("(%d+)%s+(%S+)") do
				allowed[tonumber(id)] = layout
			end
			if not allowed[focusedID] or allowed[focusedID] == "floating" then
				return -- Settings, floating tools, and unmanaged popups keep focus.
			end
			local function contains(frame)
				return point.x >= frame.x
					and point.x < frame.x + frame.w
					and point.y >= frame.y
					and point.y < frame.y + frame.h
			end
			if not contains(screen:frame()) then
				return -- Leave the menu bar and Dock alone.
			end
			for _, window in ipairs(runtime.window.orderedWindows()) do
				if contains(window:frame()) then
					if allowed[window:id()] and window:isStandard() and window:id() ~= focusedID then
						window:focus()
					end
					return -- Never focus through a covering window or dialog.
				end
			end
		end, { "list-windows", "--workspace", "focused", "--format", "%{window-id} %{window-layout}" })
		if not task or not task:start() then
			task = nil
			onError("Unable to start hover query")
		elseif task then
			timeout:start()
		end
	end)

	cancel = function()
		generation = generation + 1
		pending = false
		timer:stop()
		timeout:stop()
		local previous = task
		task = nil
		if previous then
			previous:terminate()
		end
	end
	timeout = oneShot(runtime.timer, options.commandTimeout, function()
		cancel()
		onError("Hover query timed out")
	end)
	local function requestFocus()
		if blocked() then
			cancel()
		elseif not task and not pending then
			-- Throttle checks so focus can change while the pointer is still moving.
			pending = true
			timer:start()
		end
		return false
	end
	local tap = runtime.eventtap.new({ runtime.eventtap.event.types.mouseMoved }, requestFocus)
	return {
		request = requestFocus,
		start = function(self)
			active = true
			tap:start()
			return self
		end,
		stop = function(self)
			active = false
			cancel()
			tap:stop()
			return self
		end,
		cancel = cancel,
		isEnabled = function()
			return tap:isEnabled()
		end,
	}
end

function ControllerModule.new(options, runtime)
	local self = setmetatable({
		options = options,
		runtime = runtime,
		logger = options.logger or runtime.logger.new("AeroSpaceSwipe", "warning"),
		recognizer = ControllerModule.newRecognizer(options),
		queue = {},
		retiring = {},
		durations = {},
		recognized = 0,
		switched = 0,
		errors = 0,
		timedOut = 0,
	}, Controller)
	local types = runtime.eventtap.event.types
	self.gestureTap = runtime.eventtap.new({ types.gesture }, function(event)
		if event:getType(true) == types.gesture then
			self:handleTouches(event:getTouches())
		end
		return false
	end)
	self.scrollTap = runtime.eventtap.new({ types.scrollWheel }, function(event)
		return self:shouldBlockScroll(event)
	end)
	self.pointerTap = runtime.eventtap.new({ types.mouseMoved, types.leftMouseDragged }, function()
		return self.swipeActive == true
	end)
	self.releaseTimeout = oneShot(runtime.timer, releaseConfirmationDelay, function()
		if self.recognizer:confirmRelease() then
			self:releaseInput(self.swipeActive or self.blockMomentum)
		end
	end)
	self.touchTimeout = oneShot(runtime.timer, options.touchTimeout or 0.5, function()
		self.recognizer:expire()
		self:releaseInput(false)
	end)
	self.momentumTimeout = oneShot(runtime.timer, 0.5, function()
		self.blockMomentum = false
	end)
	self.dispatchTimer = oneShot(runtime.timer, 0, function()
		self.dispatchScheduled = false
		self:runNextCommand()
	end)
	self.commandTimeout = oneShot(runtime.timer, options.commandTimeout or 1, function()
		self.timedOut = self.timedOut + 1
		self:recordError("AeroSpace command timed out; pending commands discarded")
		self:cancelCommands()
		self.lastScreen = runtime.mouse.getCurrentScreen()
		self:releaseInput(false)
	end)
	self.monitorTimer = runtime.timer.new(0.25, function()
		self:focusPointerMonitor()
	end)
	if options.windowFocusFollowsMouse then
		self.hoverFocus = ControllerModule.newHoverFocus(options, runtime, function()
			return not self.running
				or self.swipeActive
				or self.blockMomentum
				or self.activeCommand ~= nil
				or #self.queue > 0
		end, function(message)
			self:recordError(message)
		end)
	end
	self.wakeWatcher = runtime.caffeinate.watcher.new(function(event)
		self:handleSleepWake(event)
	end)
	return self
end

function Controller:now()
	return self.runtime.timer.absoluteTime() / 1e9
end

function Controller:scheduleCommand()
	if not self.activeCommand and not self.dispatchScheduled and #self.queue > 0 then
		self.dispatchScheduled = true
		self.dispatchTimer:start()
	end
end

function Controller:focusPointerMonitor()
	if
		self.swipeActive
		or self.blockMomentum
		or self.activeCommand
		or #self.queue > 0
		or next(self.runtime.eventtap.checkMouseButtons()) ~= nil
	then
		return
	end
	local screen = self.runtime.mouse.getCurrentScreen()
	if screen and screen ~= self.lastScreen and not pointerFocusBlocked(self.runtime) then
		self:queueCommand({
			kind = "pointer",
			screen = screen,
			args = {
				"eval",
				"test-not %{window-layout} = floating && focus-monitor "
					.. quoteArgument(displayPattern(screen:name())),
			},
		})
	end
end

function Controller:handleSleepWake(event)
	local watcher = self.runtime.caffeinate.watcher
	local sleeping = event == watcher.systemWillSleep
		or event == watcher.screensDidSleep
		or event == watcher.screensDidLock
	local waking = event == watcher.systemDidWake
		or event == watcher.screensDidWake
		or event == watcher.screensDidUnlock
	if not sleeping and not waking then
		return
	end
	self:cancelCommands()
	self:releaseInput(false)
	self.releaseTimeout:stop()
	self.recognizer:reset()
	self.lastScreen = nil
	self.monitorTimer:stop()
	if self.hoverFocus then
		self.hoverFocus:stop()
	end
	if self.running and waking then
		self.gestureTap:start()
		self.scrollTap:start()
		if self.hoverFocus then
			self.hoverFocus:start()
		end
		if self.options.focusFollowsMouse then
			self.monitorTimer:start()
		end
	end
end

function Controller:recordError(message)
	self.errors, self.lastError = self.errors + 1, message
	self.logger:w(message)
end

function Controller:releaseInput(keepMomentum)
	self.swipeActive = false
	self.pointerTap:stop()
	self.touchTimeout:stop()
	self.blockMomentum = keepMomentum
	if keepMomentum then
		self.momentumTimeout:start()
	else
		self.momentumTimeout:stop()
	end
end

function Controller:cancelCommands()
	if self.hoverFocus then
		self.hoverFocus:cancel()
	end
	self.queue = {}
	self.dispatchScheduled = false
	self.dispatchTimer:stop()
	self.commandTimeout:stop()
	local request = self.activeCommand
	self.activeCommand = nil
	if request and request.task then
		self.retiring[request.task] = true
		request.task:terminate()
	end
end

function Controller:completeCommand(request, code, stderr)
	if request.task then
		self.retiring[request.task] = nil
	end
	if self.activeCommand ~= request then
		return -- Ignore completion from a cancelled task.
	end
	self.commandTimeout:stop()
	self.activeCommand = nil
	self.durations[#self.durations + 1] = (self:now() - request.started) * 1000
	if #self.durations > 20 then
		table.remove(self.durations, 1)
	end
	if request.kind == "pointer" and code == 1 and (stderr or "") == "" then
		-- A floating window rejected automatic focus; retry only on later polling.
		self:scheduleCommand()
		return
	end
	if code == 0 then
		if request.kind == "swipe" then
			self.switched = self.switched + 1
			-- AeroSpace focus callbacks can warp the pointer despite the event tap.
			-- Restore it before monitor polling mistakes the warp for user input.
			if self.runtime.mouse.getCurrentScreen() ~= request.screen then
				for _, screen in ipairs(self.runtime.screen.allScreens()) do
					if screen == request.screen then
						local point, frame = request.pointer, screen:fullFrame()
						if
							point.x < frame.x
							or point.x >= frame.x + frame.w
							or point.y < frame.y
							or point.y >= frame.y + frame.h
						then
							point = { x = frame.x + frame.w / 2, y = frame.y + frame.h / 2 }
						end
						self.runtime.mouse.absolutePosition(point)
						break
					end
				end
			end
		end
		self.lastScreen = request.screen or self.runtime.mouse.getCurrentScreen()
		if request.kind == "pointer" and self.hoverFocus then
			self.hoverFocus:request() -- Select the window under the pointer after crossing.
		end
	else
		self:recordError("AeroSpace " .. request.kind .. " failed (" .. tostring(code) .. "): " .. (stderr or ""))
		self.queue = {}
		self.lastScreen = self.runtime.mouse.getCurrentScreen()
		self:releaseInput(false)
	end
	if self.running and #self.queue > 0 then
		self:scheduleCommand()
	end
end

function Controller:runNextCommand()
	if not self.running or self.activeCommand or #self.queue == 0 then
		return
	end
	local request = table.remove(self.queue, 1)
	if
		request.kind == "pointer"
		and (
			pointerFocusBlocked(self.runtime)
			or self.runtime.mouse.getCurrentScreen() ~= request.screen
			or next(self.runtime.eventtap.checkMouseButtons()) ~= nil
		)
	then
		self:scheduleCommand()
		return
	end
	request.started = self:now()
	self.activeCommand = request
	request.task = self.runtime.task.new(self.options.aerospacePath, function(code, _, stderr)
		self:completeCommand(request, code, stderr)
	end, request.args)
	if not request.task or not request.task:start() then
		self:completeCommand(request, "start", "Unable to start CLI")
	elseif self.activeCommand == request then
		self.commandTimeout:start()
	end
end

function Controller:queueCommand(request)
	if not self.running then
		return
	end
	if self.hoverFocus then
		self.hoverFocus:cancel()
	end
	for i = #self.queue, 1, -1 do
		if self.queue[i].kind == "pointer" then
			table.remove(self.queue, i)
		end
	end
	self.queue[#self.queue + 1] = request
	self:scheduleCommand()
end

function Controller:focusMonitor(direction)
	self:queueCommand({
		kind = "keyboard",
		args = {
			"eval",
			"focus-monitor " .. direction .. " && move-mouse window-lazy-center || move-mouse monitor-lazy-center",
		},
	})
end

function Controller:handleTouches(touches)
	local wasReleasePending = self.recognizer.releasePending
	local direction, released = self.recognizer:update(touches)
	if self.recognizer.releasePending then
		if not wasReleasePending then
			self.releaseTimeout:start()
		end
	else
		self.releaseTimeout:stop()
	end
	if released then
		self:releaseInput(self.swipeActive or self.blockMomentum)
	end
	if direction then
		self.recognized = self.recognized + 1
		local screen = self.runtime.mouse.getCurrentScreen()
		if not screen then
			self:recordError("No display under pointer for swipe")
			return
		end
		self.swipeActive = true
		self.pointerTap:start()
		self.blockMomentum = false
		self.momentumTimeout:stop()
		local expression = "focus-monitor "
			.. quoteArgument(displayPattern(screen:name()))
			.. " && workspace --no-stdin --wrap-around "
			.. (direction == "left" and "next" or "prev")
		local pointer = self.runtime.mouse.absolutePosition()
		self:queueCommand({
			kind = "swipe",
			screen = screen,
			pointer = { x = pointer.x, y = pointer.y },
			args = { "eval", expression },
		})
	end
	if touches and self.swipeActive then
		self.touchTimeout:start()
	end
end

function Controller:shouldBlockScroll(event)
	if self.swipeActive then
		return true
	end
	if not self.blockMomentum then
		return false
	end
	local properties = self.runtime.eventtap.event.properties
	if event:getProperty(properties.scrollWheelEventIsContinuous) == 0 then
		return false
	end
	local momentum = event:getProperty(properties.scrollWheelEventMomentumPhase)
	local phase = event:getProperty(properties.scrollWheelEventScrollPhase)
	local newScroll = phase % 2 == 1 or phase >= 128
	if momentum == 0 and newScroll then
		self.blockMomentum = false
		self.momentumTimeout:stop()
		return false
	end
	if momentum == 3 then
		self.blockMomentum = false
		self.momentumTimeout:stop()
	else
		self.momentumTimeout:start()
	end
	return true
end

function Controller:start()
	if self.running then
		return self
	end
	self.running = true
	self.releaseTimeout:stop()
	self.recognizer:reset()
	self.lastScreen = self.runtime.mouse.getCurrentScreen()
	self.gestureTap:start()
	self.scrollTap:start()
	if self.hoverFocus then
		self.hoverFocus:start()
	end
	if self.options.focusFollowsMouse then
		self.monitorTimer:start()
	end
	self.wakeWatcher:start()
	return self
end

function Controller:stop()
	self.running = false
	self:cancelCommands()
	self:releaseInput(false)
	self.releaseTimeout:stop()
	self.recognizer:reset()
	self.gestureTap:stop()
	self.scrollTap:stop()
	if self.hoverFocus then
		self.hoverFocus:stop()
	end
	self.monitorTimer:stop()
	self.wakeWatcher:stop()
	return self
end

function Controller:status()
	local durations = {}
	for i, value in ipairs(self.durations) do
		durations[i] = value
	end
	return {
		running = self.running == true,
		gestureActive = self.swipeActive == true,
		momentumBlocked = self.blockMomentum == true,
		gestureTapEnabled = self.gestureTap:isEnabled(),
		scrollTapEnabled = self.scrollTap:isEnabled(),
		pointerTapEnabled = self.pointerTap:isEnabled(),
		hoverTapEnabled = self.hoverFocus ~= nil and self.hoverFocus:isEnabled(),
		commandBusy = self.activeCommand ~= nil,
		queuedCommands = #self.queue,
		recognized = self.recognized,
		switched = self.switched,
		errors = self.errors,
		timedOut = self.timedOut,
		lastError = self.lastError,
		recentCommandMs = durations,
	}
end

local Spoon = {
	name = "AeroSpaceSwipe",
	version = "0.1.0",
	author = "Cuong Vu",
	homepage = "https://github.com/cuongvd23/AeroSpaceSwipe.spoon",
	license = "MIT - https://opensource.org/licenses/MIT",
	threshold = 0.01,
	fingerThreshold = 0.002,
	horizontalRatio = 1.5,
	touchTimeout = 0.5,
	commandTimeout = 1,
	focusFollowsMouse = false,
	windowFocusFollowsMouse = false,
	_controllerModule = ControllerModule, -- Internal constructors for local tests.
	_hotkeys = {},
	_mapping = {},
}

local monitorDirections = {
	focusMonitorLeft = "left",
	focusMonitorRight = "right",
	focusMonitorUp = "up",
	focusMonitorDown = "down",
}
local positiveSettings = { "threshold", "fingerThreshold", "horizontalRatio", "touchTimeout", "commandTimeout" }

local function isExecutable(path)
	local attributes = hs.fs.attributes(path)
	return attributes and attributes.mode == "file" and attributes.permissions:find("x", 1, true)
end

local function findAeroSpace(explicit)
	if explicit ~= nil then
		if type(explicit) == "string" and explicit:sub(1, 1) == "/" and isExecutable(explicit) then
			return explicit
		end
		return nil, "aerospacePath must name an executable file at an absolute path"
	end
	for _, path in ipairs({ "/opt/homebrew/bin/aerospace", "/usr/local/bin/aerospace" }) do
		if isExecutable(path) then
			return path
		end
	end
	return nil, "AeroSpace CLI not found; set spoon.AeroSpaceSwipe.aerospacePath"
end

function Spoon:_clearHotkeys()
	for _, hotkey in ipairs(self._hotkeys) do
		hotkey:delete()
	end
	self._hotkeys = {}
end

function Spoon:_enableHotkeys()
	self:_clearHotkeys()
	for action, binding in pairs(self._mapping) do
		local direction = monitorDirections[action]
		local callback = function()
			self:focusMonitor(direction)
		end
		local ok, hotkey = pcall(function()
			-- Omit nil; Hammerspoon would bind key release.
			if binding.message ~= nil then
				return hs.hotkey.new(binding[1], binding[2], binding.message, callback)
			end
			return hs.hotkey.new(binding[1], binding[2], callback)
		end)
		if not ok or not hotkey then
			self:_clearHotkeys()
			return nil, "Unable to create hotkey for " .. action
		end
		self._hotkeys[#self._hotkeys + 1] = hotkey
		if not hotkey:enable() then
			self:_clearHotkeys()
			return nil, "Unable to enable hotkey for " .. action
		end
	end
	return self
end

function Spoon:init()
	self.logger = self.logger or hs.logger.new("AeroSpaceSwipe", "warning")
	return self
end

function Spoon:start()
	if self._controller then
		return self
	end
	self:init()
	local options = {
		logger = self.logger,
		focusFollowsMouse = self.focusFollowsMouse,
		windowFocusFollowsMouse = self.windowFocusFollowsMouse,
	}
	local function fail(message)
		self._startError = message
		self.logger:w(message)
		return nil, message
	end
	for _, key in ipairs(positiveSettings) do
		local value = self[key]
		if type(value) ~= "number" or value ~= value or value <= 0 or value == math.huge then
			return fail(key .. " must be a positive finite number")
		end
		options[key] = value
	end
	if type(options.focusFollowsMouse) ~= "boolean" then
		return fail("focusFollowsMouse must be a boolean")
	end
	if type(options.windowFocusFollowsMouse) ~= "boolean" then
		return fail("windowFocusFollowsMouse must be a boolean")
	end
	local path, err = findAeroSpace(self.aerospacePath)
	if not path then
		return fail(err)
	end
	options.aerospacePath = path
	local controller = ControllerModule.new(options, hs):start()
	local state = controller:status()
	if
		not state.gestureTapEnabled
		or not state.scrollTapEnabled
		or (options.windowFocusFollowsMouse and not state.hoverTapEnabled)
	then
		controller:stop()
		return fail("Unable to start input listeners; check Hammerspoon Accessibility permission")
	end
	self._controller, self._resolvedPath, self._startError = controller, path, nil
	local ok, hotkeyError = self:_enableHotkeys()
	if not ok then
		self:stop()
		return fail(hotkeyError)
	end
	return self
end

function Spoon:stop()
	self:_clearHotkeys()
	if self._controller then
		self._controller:stop()
		self._lastStatus = self._controller:status()
		self._controller = nil
	end
	return self
end

function Spoon:status()
	local source = self._controller and self._controller:status()
		or self._lastStatus
		or {
			running = false,
			gestureActive = false,
			momentumBlocked = false,
			gestureTapEnabled = false,
			scrollTapEnabled = false,
			pointerTapEnabled = false,
			hoverTapEnabled = false,
			commandBusy = false,
			queuedCommands = 0,
			recognized = 0,
			switched = 0,
			errors = 0,
			timedOut = 0,
			recentCommandMs = {},
		}
	local state = {}
	for key, value in pairs(source) do
		state[key] = value
	end
	state.recentCommandMs = {}
	for i, value in ipairs(source.recentCommandMs) do
		state.recentCommandMs[i] = value
	end
	state.lastError = self._startError or source.lastError
	state.aerospacePath = self._resolvedPath
	state.boundHotkeys = #self._hotkeys
	return state
end

function Spoon:focusMonitor(direction)
	if direction ~= "left" and direction ~= "right" and direction ~= "up" and direction ~= "down" then
		return nil, "Invalid monitor direction"
	end
	if not self._controller then
		return nil, "AeroSpaceSwipe is stopped"
	end
	self._controller:focusMonitor(direction)
	return self
end

function Spoon:bindHotkeys(mapping)
	if type(mapping) ~= "table" then
		return nil, "Hotkey mapping must be a table"
	end
	local bindings = {}
	for action, binding in pairs(mapping) do
		if
			not monitorDirections[action]
			or type(binding) ~= "table"
			or type(binding[1]) ~= "table"
			or (type(binding[2]) ~= "string" and type(binding[2]) ~= "number")
			or (binding.message ~= nil and type(binding.message) ~= "string")
		then
			return nil, "Invalid hotkey binding: " .. tostring(action)
		end
		local modifiers = {}
		for i, modifier in ipairs(binding[1]) do
			modifiers[i] = modifier
		end
		bindings[action] = { modifiers, binding[2], message = binding.message }
	end
	self._mapping = bindings
	if self._controller then
		return self:_enableHotkeys()
	end
	return self
end

return Spoon
